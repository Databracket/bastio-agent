Building deb package
====================

* ./debbuild.sh

