Bastio Agent
============

An agent for Bastio service to provision system accounts and SSH access.
